# dynasub

Use `${var}` syntax to substitute variables into Python code at runtime.

## Install

```bash
pip install dynasub
```

## Usage

Add `# -*- coding: dynasub -*-` to the top of your file. Then wrap lines you want substituted in `"#$ ..."` strings:

```python
# -*- coding: dynasub -*-

keywords = ['sum', 'max', 'min']
data = [[3,1,2],[1,2,3],[2,3,1]]

for i in keywords:
    "#$ result_${i} = sorted(data, key=lambda x: ${i}(x))"

print(result_sum)
print(result_max)
print(result_min)
```

## Multi-line blocks

Consecutive `"#$ ..."` lines are grouped into one block:

```python
# -*- coding: dynasub -*-

for i in keywords:
    "#$ if '${i}' == 'sum':"
    "#$     special = sorted(data, key=lambda x: ${i}(x))"

print(special)
```

## Runtime values

`${var}` is always evaluated at runtime — works with user input, loop variables, anything:

```python
# -*- coding: dynasub -*-

i = input("function name: ")  # user types "sum"
"#$ result = sorted(data, key=lambda x: ${i}(x))"
print(result)
```

## How it works

dynasub registers a custom Python codec via a `.pth` file that runs at startup.
When Python sees `# -*- coding: dynasub -*-`, it passes the source through the
codec before compiling. Any `"#$ ..."` line gets transformed into
`exec(f"...", globals())`. Python then compiles and runs the result normally.

## Limitations

- Only works at module level — not inside functions
- f-strings inside `"#$ ..."` lines conflict with the outer f-string
- String comparisons need quotes: use `'${i}'` not `${i}`
