from setuptools import setup
import site, os

# find the correct site-packages dir
site_packages = site.getusersitepackages() if hasattr(site, 'getusersitepackages') else site.getsitepackages()[0]

setup(
    data_files=[
        (site_packages, ['dynasub.pth'])
    ]
)
